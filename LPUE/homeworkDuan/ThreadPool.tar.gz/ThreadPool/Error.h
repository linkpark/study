#ifndef ERROR_H_
#define ERROR_H_

const int SUCCESSFUL = 0;
const int FAILED = -1;

#endif
